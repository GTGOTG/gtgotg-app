"""
Admin routes for GTGOTG application
Handles admin authentication, dashboard, and management functions
"""

from flask import Blueprint, request, jsonify, render_template
from datetime import datetime, timedelta
import json
from ..models.admin import admin_manager

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route('/')
def admin_dashboard():
    """Serve admin dashboard page"""
    return render_template('admin/dashboard.html')

@admin_bp.route('/login', methods=['POST'])
def admin_login():
    """Admin login endpoint"""
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({'success': False, 'message': 'Username and password required'}), 400
        
        result = admin_manager.authenticate(username, password)
        
        if result['success']:
            return jsonify(result), 200
        else:
            return jsonify(result), 401
            
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@admin_bp.route('/logout', methods=['POST'])
def admin_logout():
    """Admin logout endpoint"""
    try:
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        result = admin_manager.logout(token)
        return jsonify(result), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@admin_bp.route('/verify', methods=['GET'])
def verify_admin():
    """Verify admin session"""
    try:
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        result = admin_manager.verify_session(token)
        
        if result['valid']:
            admin_data = result['admin']
            return jsonify({
                'valid': True,
                'admin': {
                    'username': result['username'],
                    'email': admin_data['email'],
                    'role': admin_data['role'],
                    'permissions': admin_data['permissions'],
                    'last_login': admin_data['last_login'].isoformat() if admin_data['last_login'] else None
                }
            }), 200
        else:
            return jsonify({'valid': False}), 401
            
    except Exception as e:
        return jsonify({'valid': False, 'message': str(e)}), 500

@admin_bp.route('/dashboard/stats', methods=['GET'])
def dashboard_stats():
    """Get dashboard statistics"""
    try:
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        
        if not admin_manager.has_permission(token, 'view_dashboard'):
            return jsonify({'error': 'Insufficient permissions'}), 403
        
        # Mock data for demonstration - in real app, this would query the database
        stats = {
            'overview': {
                'total_users': 1247,
                'total_businesses': 3892,
                'total_reviews': 8934,
                'verified_businesses': 2156,
                'active_users_30d': 892,
                'new_users_7d': 67
            },
            'revenue': {
                'monthly_revenue': 4250.00,
                'advertising_revenue': 2800.00,
                'subscription_revenue': 1450.00,
                'growth_rate': 12.5
            },
            'engagement': {
                'reviews_this_month': 234,
                'avg_rating': 4.2,
                'response_rate': 78.5,
                'user_retention': 65.2
            },
            'recent_activity': [
                {
                    'type': 'new_business',
                    'message': 'Shell Gas Station claimed their listing',
                    'timestamp': (datetime.now() - timedelta(hours=2)).isoformat()
                },
                {
                    'type': 'new_review',
                    'message': 'New 5-star review for Starbucks Coffee',
                    'timestamp': (datetime.now() - timedelta(hours=4)).isoformat()
                },
                {
                    'type': 'user_signup',
                    'message': '5 new users registered today',
                    'timestamp': (datetime.now() - timedelta(hours=6)).isoformat()
                }
            ]
        }
        
        return jsonify(stats), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/users', methods=['GET'])
def get_users():
    """Get user list for management"""
    try:
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        
        if not admin_manager.has_permission(token, 'manage_users'):
            return jsonify({'error': 'Insufficient permissions'}), 403
        
        # Mock user data
        users = [
            {
                'id': 1,
                'username': 'john_doe',
                'email': 'john@example.com',
                'badge': 'Gold',
                'reviews_count': 23,
                'joined_date': '2024-01-15',
                'status': 'active',
                'last_active': '2025-01-20'
            },
            {
                'id': 2,
                'username': 'jane_smith',
                'email': 'jane@example.com',
                'badge': 'Silver',
                'reviews_count': 12,
                'joined_date': '2024-03-22',
                'status': 'active',
                'last_active': '2025-01-19'
            },
            {
                'id': 3,
                'username': 'mike_wilson',
                'email': 'mike@example.com',
                'badge': 'Bronze',
                'reviews_count': 7,
                'joined_date': '2024-06-10',
                'status': 'suspended',
                'last_active': '2025-01-15'
            }
        ]
        
        return jsonify({'users': users}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/businesses', methods=['GET'])
def get_businesses():
    """Get business list for management"""
    try:
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        
        if not admin_manager.has_permission(token, 'manage_businesses'):
            return jsonify({'error': 'Insufficient permissions'}), 403
        
        # Mock business data
        businesses = [
            {
                'id': 1,
                'name': 'Shell Gas Station',
                'address': '100 Main Street, New York, NY',
                'type': 'Gas Station',
                'status': 'verified',
                'owner_email': 'manager@shell.com',
                'reviews_count': 45,
                'avg_rating': 4.2,
                'claimed_date': '2024-02-10'
            },
            {
                'id': 2,
                'name': 'Starbucks Coffee',
                'address': '211 Main Street, New York, NY',
                'type': 'Coffee Shop',
                'status': 'pending',
                'owner_email': 'store@starbucks.com',
                'reviews_count': 32,
                'avg_rating': 4.5,
                'claimed_date': '2025-01-18'
            },
            {
                'id': 3,
                'name': 'McDonald\'s',
                'address': '305 Broadway, New York, NY',
                'type': 'Restaurant',
                'status': 'unrated',
                'owner_email': None,
                'reviews_count': 28,
                'avg_rating': 3.8,
                'claimed_date': None
            }
        ]
        
        return jsonify({'businesses': businesses}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/analytics/export', methods=['GET'])
def export_analytics():
    """Export analytics data for potential buyers"""
    try:
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        
        if not admin_manager.has_permission(token, 'export_data'):
            return jsonify({'error': 'Insufficient permissions'}), 403
        
        # Comprehensive analytics for potential buyers
        export_data = {
            'business_overview': {
                'app_name': 'GTGOTG - Got To Go On The Go',
                'launch_date': '2024-01-01',
                'total_users': 1247,
                'monthly_active_users': 892,
                'total_businesses': 3892,
                'verified_businesses': 2156,
                'total_reviews': 8934,
                'geographic_coverage': 'Nationwide USA'
            },
            'financial_metrics': {
                'monthly_recurring_revenue': 4250.00,
                'annual_run_rate': 51000.00,
                'revenue_growth_rate': 12.5,
                'customer_acquisition_cost': 15.50,
                'lifetime_value': 125.00,
                'revenue_streams': {
                    'advertising': 2800.00,
                    'business_subscriptions': 1450.00
                }
            },
            'user_engagement': {
                'avg_session_duration': '4.2 minutes',
                'monthly_reviews': 234,
                'user_retention_30d': 65.2,
                'daily_active_users': 156,
                'reviews_per_user': 7.2
            },
            'market_position': {
                'unique_value_proposition': 'Nationwide restroom finder with safety ratings',
                'competitive_advantages': [
                    'Comprehensive amenities checklist',
                    'Safety and cleanliness ratings',
                    'Business owner engagement system',
                    'User badge gamification'
                ],
                'target_market': 'Travelers, families, accessibility-conscious users'
            },
            'technology_stack': {
                'frontend': 'HTML/CSS/JavaScript',
                'backend': 'Python Flask',
                'database': 'SQLite/PostgreSQL ready',
                'hosting': 'Cloud-ready deployment',
                'apis': 'OpenStreetMap integration'
            },
            'growth_metrics': {
                'user_growth_rate': 8.5,
                'business_signup_rate': 15.2,
                'review_growth_rate': 22.1,
                'geographic_expansion': 'All 50 states covered'
            }
        }
        
        return jsonify(export_data), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

