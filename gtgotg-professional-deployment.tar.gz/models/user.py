from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    first_name = db.Column(db.String(50), nullable=True)
    last_name = db.Column(db.String(50), nullable=True)
    location = db.Column(db.String(100), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Badge system fields
    review_count = db.Column(db.Integer, default=0)
    badge_level = db.Column(db.String(20), default='Reviewer')  # Reviewer, Bronze, Silver, Gold, Platinum, Expert
    reviewed_businesses = db.Column(db.Text, default='[]')  # JSON array of business IDs reviewed
    
    # User engagement tracking
    total_helpful_votes = db.Column(db.Integer, default=0)
    photos_uploaded = db.Column(db.Integer, default=0)
    is_verified = db.Column(db.Boolean, default=False)
    
    def __repr__(self):
        return f'<User {self.username}>'
    
    def get_reviewed_businesses(self):
        """Get list of business IDs this user has reviewed"""
        try:
            return json.loads(self.reviewed_businesses or '[]')
        except:
            return []
    
    def add_reviewed_business(self, business_id):
        """Add a business ID to the reviewed list and update badge"""
        reviewed = self.get_reviewed_businesses()
        if business_id not in reviewed:
            reviewed.append(business_id)
            self.reviewed_businesses = json.dumps(reviewed)
            self.review_count = len(reviewed)
            self.update_badge_level()
    
    def update_badge_level(self):
        """Update user badge level based on review count"""
        if self.review_count >= 25:
            self.badge_level = 'Expert'
        elif self.review_count >= 20:
            self.badge_level = 'Platinum'
        elif self.review_count >= 15:
            self.badge_level = 'Gold'
        elif self.review_count >= 10:
            self.badge_level = 'Silver'
        elif self.review_count >= 5:
            self.badge_level = 'Bronze'
        else:
            self.badge_level = 'Reviewer'
    
    def get_badge_info(self):
        """Get badge information including icon and next level requirements"""
        badge_info = {
            'Reviewer': {'icon': '👤', 'color': '#6B7280', 'next_level': 'Bronze', 'reviews_needed': 5 - self.review_count},
            'Bronze': {'icon': '🥉', 'color': '#CD7F32', 'next_level': 'Silver', 'reviews_needed': 10 - self.review_count},
            'Silver': {'icon': '🥈', 'color': '#C0C0C0', 'next_level': 'Gold', 'reviews_needed': 15 - self.review_count},
            'Gold': {'icon': '🥇', 'color': '#FFD700', 'next_level': 'Platinum', 'reviews_needed': 20 - self.review_count},
            'Platinum': {'icon': '💎', 'color': '#E5E4E2', 'next_level': 'Expert', 'reviews_needed': 25 - self.review_count},
            'Expert': {'icon': '👑', 'color': '#9333EA', 'next_level': None, 'reviews_needed': 0}
        }
        
        current_badge = badge_info.get(self.badge_level, badge_info['Reviewer'])
        if current_badge['reviews_needed'] <= 0 and current_badge['next_level']:
            current_badge['reviews_needed'] = 0
            
        return current_badge

    def to_dict(self):
        badge_info = self.get_badge_info()
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'location': self.location,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'review_count': self.review_count,
            'badge_level': self.badge_level,
            'badge_icon': badge_info['icon'],
            'badge_color': badge_info['color'],
            'next_badge': badge_info['next_level'],
            'reviews_until_next_badge': badge_info['reviews_needed'],
            'total_helpful_votes': self.total_helpful_votes,
            'photos_uploaded': self.photos_uploaded,
            'is_verified': self.is_verified
        }


class Review(db.Model):
    """User reviews for businesses"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    business_id = db.Column(db.String(100), nullable=False)
    
    # Ratings (1-5 scale)
    overall_rating = db.Column(db.Float, nullable=False)
    cleanliness_rating = db.Column(db.Float, nullable=False)
    safety_rating = db.Column(db.Float, nullable=False)
    accessibility_rating = db.Column(db.Float, nullable=True)
    
    # Review content
    comment = db.Column(db.Text, nullable=True)
    photos = db.Column(db.Text, default='[]')  # JSON array of photo URLs
    
    # Amenities checklist
    amenities_data = db.Column(db.Text, default='{}')  # JSON object of amenity checks
    
    # Engagement
    helpful_votes = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('reviews', lazy=True))
    
    def get_amenities(self):
        """Get amenities checklist as dict"""
        try:
            return json.loads(self.amenities_data or '{}')
        except:
            return {}
    
    def set_amenities(self, amenities_dict):
        """Set amenities checklist from dict"""
        self.amenities_data = json.dumps(amenities_dict)
    
    def get_photos(self):
        """Get list of photo URLs"""
        try:
            return json.loads(self.photos or '[]')
        except:
            return []
    
    def add_photo(self, photo_url):
        """Add a photo URL to the review"""
        photos = self.get_photos()
        photos.append(photo_url)
        self.photos = json.dumps(photos)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'business_id': self.business_id,
            'overall_rating': self.overall_rating,
            'cleanliness_rating': self.cleanliness_rating,
            'safety_rating': self.safety_rating,
            'accessibility_rating': self.accessibility_rating,
            'comment': self.comment,
            'photos': self.get_photos(),
            'amenities': self.get_amenities(),
            'helpful_votes': self.helpful_votes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'user': self.user.to_dict() if self.user else None
        }
