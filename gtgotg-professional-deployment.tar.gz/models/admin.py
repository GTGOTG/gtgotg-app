"""
Admin model for GTGOTG application
Handles admin authentication and permissions
"""

import hashlib
import secrets
from datetime import datetime, timedelta

class Admin:
    def __init__(self):
        # In a real app, this would be stored in a database
        # For demo purposes, using in-memory storage
        self.admins = {
            'admin': {
                'password_hash': self.hash_password('gtgotg2025!'),
                'email': 'admin@gtgotg.com',
                'role': 'super_admin',
                'created_at': datetime.now(),
                'last_login': None,
                'permissions': [
                    'view_dashboard',
                    'manage_users',
                    'manage_businesses',
                    'moderate_reviews',
                    'view_analytics',
                    'export_data',
                    'manage_content',
                    'view_financials'
                ]
            }
        }
        self.sessions = {}
    
    def hash_password(self, password):
        """Hash password with salt"""
        salt = secrets.token_hex(16)
        password_hash = hashlib.pbkdf2_hmac('sha256', 
                                          password.encode('utf-8'), 
                                          salt.encode('utf-8'), 
                                          100000)
        return f"{salt}:{password_hash.hex()}"
    
    def verify_password(self, password, password_hash):
        """Verify password against hash"""
        try:
            salt, hash_hex = password_hash.split(':')
            password_hash_check = hashlib.pbkdf2_hmac('sha256',
                                                    password.encode('utf-8'),
                                                    salt.encode('utf-8'),
                                                    100000)
            return password_hash_check.hex() == hash_hex
        except:
            return False
    
    def authenticate(self, username, password):
        """Authenticate admin user"""
        if username in self.admins:
            admin = self.admins[username]
            if self.verify_password(password, admin['password_hash']):
                # Create session
                session_token = secrets.token_urlsafe(32)
                self.sessions[session_token] = {
                    'username': username,
                    'created_at': datetime.now(),
                    'expires_at': datetime.now() + timedelta(hours=8)
                }
                
                # Update last login
                admin['last_login'] = datetime.now()
                
                return {
                    'success': True,
                    'token': session_token,
                    'admin': {
                        'username': username,
                        'email': admin['email'],
                        'role': admin['role'],
                        'permissions': admin['permissions']
                    }
                }
        
        return {'success': False, 'message': 'Invalid credentials'}
    
    def verify_session(self, token):
        """Verify admin session token"""
        if token in self.sessions:
            session = self.sessions[token]
            if datetime.now() < session['expires_at']:
                return {
                    'valid': True,
                    'username': session['username'],
                    'admin': self.admins[session['username']]
                }
            else:
                # Remove expired session
                del self.sessions[token]
        
        return {'valid': False}
    
    def logout(self, token):
        """Logout admin user"""
        if token in self.sessions:
            del self.sessions[token]
            return {'success': True}
        return {'success': False}
    
    def has_permission(self, token, permission):
        """Check if admin has specific permission"""
        session_info = self.verify_session(token)
        if session_info['valid']:
            admin = session_info['admin']
            return permission in admin['permissions']
        return False

# Global admin instance
admin_manager = Admin()

