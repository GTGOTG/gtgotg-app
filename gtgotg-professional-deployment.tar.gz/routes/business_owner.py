#!/usr/bin/env python3
"""
Business Owner API routes for GTGOTG
Handles business owner registration, authentication, claims, and dashboard
"""

from flask import Blueprint, request, jsonify, session
from werkzeug.security import generate_password_hash, check_password_hash
from src.models.business_owner import db, BusinessOwner, BusinessClaim, ReviewResponse
from src.models.user import Review
import secrets
import re
from datetime import datetime, timedelta

business_owner_bp = Blueprint('business_owner', __name__)

@business_owner_bp.route('/api/business-owner/register', methods=['POST'])
def register_business_owner():
    """Register a new business owner"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['email', 'password', 'first_name', 'last_name']
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Validate email format
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(email_pattern, data['email']):
            return jsonify({'error': 'Invalid email format'}), 400
        
        # Check if email already exists
        existing_owner = BusinessOwner.query.filter_by(email=data['email']).first()
        if existing_owner:
            return jsonify({'error': 'Email already registered'}), 400
        
        # Validate password strength
        password = data['password']
        if len(password) < 8:
            return jsonify({'error': 'Password must be at least 8 characters long'}), 400
        
        # Create new business owner
        business_owner = BusinessOwner(
            email=data['email'],
            password_hash=generate_password_hash(password),
            first_name=data['first_name'],
            last_name=data['last_name'],
            phone=data.get('phone', ''),
            company_name=data.get('company_name', ''),
            verification_token=secrets.token_urlsafe(32)
        )
        
        db.session.add(business_owner)
        db.session.commit()
        
        return jsonify({
            'message': 'Business owner account created successfully!',
            'business_owner': business_owner.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Registration failed: {str(e)}'}), 500

@business_owner_bp.route('/api/business-owner/login', methods=['POST'])
def login_business_owner():
    """Login business owner"""
    try:
        data = request.get_json()
        
        if not data.get('email') or not data.get('password'):
            return jsonify({'error': 'Email and password are required'}), 400
        
        business_owner = BusinessOwner.query.filter_by(email=data['email']).first()
        
        if not business_owner or not check_password_hash(business_owner.password_hash, data['password']):
            return jsonify({'error': 'Invalid email or password'}), 401
        
        # Update last login
        business_owner.last_login = datetime.utcnow()
        db.session.commit()
        
        # Set session
        session['business_owner_id'] = business_owner.id
        session['business_owner_email'] = business_owner.email
        
        return jsonify({
            'message': 'Login successful',
            'business_owner': business_owner.to_dict()
        })
        
    except Exception as e:
        return jsonify({'error': f'Login failed: {str(e)}'}), 500

@business_owner_bp.route('/api/business-owner/logout', methods=['POST'])
def logout_business_owner():
    """Logout business owner"""
    session.pop('business_owner_id', None)
    session.pop('business_owner_email', None)
    return jsonify({'message': 'Logged out successfully'})

@business_owner_bp.route('/api/business-owner/profile', methods=['GET'])
def get_business_owner_profile():
    """Get business owner profile and dashboard data"""
    try:
        if 'business_owner_id' not in session:
            return jsonify({'error': 'Login required'}), 401
        
        business_owner = BusinessOwner.query.get(session['business_owner_id'])
        if not business_owner:
            return jsonify({'error': 'Business owner not found'}), 404
        
        # Get claimed businesses with recent activity
        claimed_business_ids = business_owner.get_claimed_businesses()
        
        # Get recent reviews for claimed businesses
        recent_reviews = []
        if claimed_business_ids:
            recent_reviews = Review.query.filter(
                Review.business_id.in_(claimed_business_ids)
            ).order_by(Review.created_at.desc()).limit(10).all()
        
        # Get pending claims
        pending_claims = BusinessClaim.query.filter_by(
            business_owner_id=business_owner.id,
            status='pending'
        ).all()
        
        # Calculate dashboard metrics
        total_reviews = Review.query.filter(
            Review.business_id.in_(claimed_business_ids)
        ).count() if claimed_business_ids else 0
        
        # Get responses made by this owner
        owner_responses = ReviewResponse.query.filter_by(
            business_owner_id=business_owner.id
        ).all()
        
        return jsonify({
            'business_owner': business_owner.to_dict(),
            'dashboard': {
                'total_claimed_businesses': len(claimed_business_ids),
                'total_reviews_received': total_reviews,
                'total_responses_made': len(owner_responses),
                'pending_claims': len(pending_claims),
                'recent_reviews': [review.to_dict() for review in recent_reviews],
                'pending_claims_list': [claim.to_dict() for claim in pending_claims]
            }
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to get profile: {str(e)}'}), 500

@business_owner_bp.route('/api/business-owner/claim-business', methods=['POST'])
def claim_business():
    """Claim ownership of a business"""
    try:
        if 'business_owner_id' not in session:
            return jsonify({'error': 'Login required'}), 401
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['business_id', 'business_name', 'business_address']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        business_owner_id = session['business_owner_id']
        
        # Check if business is already claimed
        existing_claim = BusinessClaim.query.filter_by(
            business_id=data['business_id']
        ).filter(BusinessClaim.status.in_(['pending', 'approved'])).first()
        
        if existing_claim:
            return jsonify({'error': 'This business is already claimed or has a pending claim'}), 400
        
        # Create new claim
        claim = BusinessClaim(
            business_owner_id=business_owner_id,
            business_id=data['business_id'],
            business_name=data['business_name'],
            business_address=data['business_address'],
            verification_method=data.get('verification_method', 'email')
        )
        
        # Set verification data
        verification_data = {
            'contact_email': data.get('contact_email', ''),
            'contact_phone': data.get('contact_phone', ''),
            'additional_info': data.get('additional_info', '')
        }
        claim.set_verification_data(verification_data)
        
        db.session.add(claim)
        db.session.commit()
        
        return jsonify({
            'message': 'Business claim submitted successfully! We will review your claim within 24-48 hours.',
            'claim': claim.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Failed to claim business: {str(e)}'}), 500

@business_owner_bp.route('/api/business-owner/approve-claim/<int:claim_id>', methods=['POST'])
def approve_claim(claim_id):
    """Approve a business claim (admin function - simplified for demo)"""
    try:
        claim = BusinessClaim.query.get_or_404(claim_id)
        
        if claim.status != 'pending':
            return jsonify({'error': 'Claim is not pending'}), 400
        
        # Approve the claim
        claim.status = 'approved'
        claim.verification_date = datetime.utcnow()
        
        # Add business to owner's claimed businesses
        business_owner = BusinessOwner.query.get(claim.business_owner_id)
        if business_owner:
            business_owner.add_claimed_business(claim.business_id)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Business claim approved successfully!',
            'claim': claim.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Failed to approve claim: {str(e)}'}), 500

@business_owner_bp.route('/api/business-owner/respond-to-review', methods=['POST'])
def respond_to_review():
    """Respond to a customer review"""
    try:
        if 'business_owner_id' not in session:
            return jsonify({'error': 'Login required'}), 401
        
        data = request.get_json()
        
        # Validate required fields
        if not data.get('review_id') or not data.get('response_text'):
            return jsonify({'error': 'Review ID and response text are required'}), 400
        
        business_owner_id = session['business_owner_id']
        business_owner = BusinessOwner.query.get(business_owner_id)
        
        # Get the review
        review = Review.query.get(data['review_id'])
        if not review:
            return jsonify({'error': 'Review not found'}), 404
        
        # Check if business owner owns this business
        claimed_businesses = business_owner.get_claimed_businesses()
        if review.business_id not in claimed_businesses:
            return jsonify({'error': 'You can only respond to reviews for your claimed businesses'}), 403
        
        # Check if response already exists
        existing_response = ReviewResponse.query.filter_by(
            review_id=data['review_id'],
            business_owner_id=business_owner_id
        ).first()
        
        if existing_response:
            return jsonify({'error': 'You have already responded to this review'}), 400
        
        # Create response
        response = ReviewResponse(
            review_id=data['review_id'],
            business_owner_id=business_owner_id,
            response_text=data['response_text']
        )
        
        db.session.add(response)
        
        # Update business owner metrics
        business_owner.response_count += 1
        
        # Calculate response time (simplified - assume review was created recently)
        if review.created_at:
            response_time = (datetime.utcnow() - review.created_at).total_seconds() / 3600  # hours
            if business_owner.avg_response_time == 0:
                business_owner.avg_response_time = response_time
            else:
                # Update running average
                total_responses = business_owner.response_count
                business_owner.avg_response_time = (
                    (business_owner.avg_response_time * (total_responses - 1) + response_time) / total_responses
                )
        
        business_owner.update_badge_level()
        db.session.commit()
        
        return jsonify({
            'message': 'Response submitted successfully!',
            'response': response.to_dict(),
            'updated_badge': business_owner.get_badge_info()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Failed to submit response: {str(e)}'}), 500

@business_owner_bp.route('/api/business-owner/my-businesses', methods=['GET'])
def get_my_businesses():
    """Get all businesses owned by the current business owner"""
    try:
        if 'business_owner_id' not in session:
            return jsonify({'error': 'Login required'}), 401
        
        business_owner = BusinessOwner.query.get(session['business_owner_id'])
        claimed_business_ids = business_owner.get_claimed_businesses()
        
        # For demo purposes, return mock business data
        # In a real app, this would query the actual business database
        businesses = []
        for business_id in claimed_business_ids:
            # Get reviews for this business
            reviews = Review.query.filter_by(business_id=business_id).all()
            
            # Calculate average ratings
            if reviews:
                avg_overall = sum(r.overall_rating for r in reviews) / len(reviews)
                avg_cleanliness = sum(r.cleanliness_rating for r in reviews) / len(reviews)
                avg_safety = sum(r.safety_rating for r in reviews) / len(reviews)
            else:
                avg_overall = avg_cleanliness = avg_safety = 0
            
            businesses.append({
                'id': business_id,
                'name': f'Business {business_id}',  # Would be actual name from business DB
                'address': f'Address for {business_id}',  # Would be actual address
                'total_reviews': len(reviews),
                'average_ratings': {
                    'overall': round(avg_overall, 1),
                    'cleanliness': round(avg_cleanliness, 1),
                    'safety': round(avg_safety, 1)
                },
                'recent_reviews': [review.to_dict() for review in reviews[-5:]]  # Last 5 reviews
            })
        
        return jsonify({
            'businesses': businesses,
            'total_businesses': len(businesses)
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to get businesses: {str(e)}'}), 500

@business_owner_bp.route('/api/business-owner/review-responses/<business_id>', methods=['GET'])
def get_review_responses(business_id):
    """Get all review responses for a specific business"""
    try:
        if 'business_owner_id' not in session:
            return jsonify({'error': 'Login required'}), 401
        
        business_owner = BusinessOwner.query.get(session['business_owner_id'])
        claimed_businesses = business_owner.get_claimed_businesses()
        
        if business_id not in claimed_businesses:
            return jsonify({'error': 'You can only view responses for your claimed businesses'}), 403
        
        # Get all reviews for this business
        reviews = Review.query.filter_by(business_id=business_id).all()
        review_ids = [review.id for review in reviews]
        
        # Get responses for these reviews
        responses = ReviewResponse.query.filter(
            ReviewResponse.review_id.in_(review_ids)
        ).order_by(ReviewResponse.response_date.desc()).all()
        
        return jsonify({
            'responses': [response.to_dict() for response in responses],
            'total_responses': len(responses)
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to get responses: {str(e)}'}), 500

@business_owner_bp.route('/api/business-owner/stats', methods=['GET'])
def get_business_owner_stats():
    """Get comprehensive statistics for business owner dashboard"""
    try:
        if 'business_owner_id' not in session:
            return jsonify({'error': 'Login required'}), 401
        
        business_owner = BusinessOwner.query.get(session['business_owner_id'])
        claimed_business_ids = business_owner.get_claimed_businesses()
        
        # Calculate various statistics
        stats = {
            'overview': {
                'total_businesses': len(claimed_business_ids),
                'total_responses': business_owner.response_count,
                'avg_response_time': round(business_owner.avg_response_time, 1),
                'customer_satisfaction': round(business_owner.customer_satisfaction, 1),
                'badge_level': business_owner.badge_level
            },
            'recent_activity': {
                'reviews_this_week': 0,
                'responses_this_week': 0,
                'new_claims_this_week': 0
            },
            'performance_trends': {
                'response_rate': 0,
                'satisfaction_trend': 'stable',
                'review_volume_trend': 'stable'
            }
        }
        
        # Get recent activity (last 7 days)
        week_ago = datetime.utcnow() - timedelta(days=7)
        
        if claimed_business_ids:
            # Reviews this week
            recent_reviews = Review.query.filter(
                Review.business_id.in_(claimed_business_ids),
                Review.created_at >= week_ago
            ).count()
            stats['recent_activity']['reviews_this_week'] = recent_reviews
        
        # Responses this week
        recent_responses = ReviewResponse.query.filter(
            ReviewResponse.business_owner_id == business_owner.id,
            ReviewResponse.response_date >= week_ago
        ).count()
        stats['recent_activity']['responses_this_week'] = recent_responses
        
        # Claims this week
        recent_claims = BusinessClaim.query.filter(
            BusinessClaim.business_owner_id == business_owner.id,
            BusinessClaim.claim_date >= week_ago
        ).count()
        stats['recent_activity']['new_claims_this_week'] = recent_claims
        
        return jsonify(stats)
        
    except Exception as e:
        return jsonify({'error': f'Failed to get stats: {str(e)}'}), 500

