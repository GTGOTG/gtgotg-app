#!/usr/bin/env python3
"""
OpenStreetMap API routes for GTGOTG
Provides endpoints for searching real nationwide business data
"""

from flask import Blueprint, request, jsonify
import sys
import os
import random

# Add the parent directory to the path to import osm_service
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

try:
    from osm_service import OpenStreetMapService, Business
except ImportError:
    # Fallback if import fails
    print("Warning: Could not import osm_service, using mock data")
    OpenStreetMapService = None
    Business = None

osm_bp = Blueprint('osm', __name__)

# Initialize OSM service
osm_service = OpenStreetMapService() if OpenStreetMapService else None

def generate_mock_rating():
    """Generate realistic mock ratings"""
    base_rating = random.uniform(3.5, 4.8)
    return {
        'overall': round(base_rating, 1),
        'cleanliness': round(base_rating + random.uniform(-0.3, 0.3), 1),
        'safety': round(base_rating + random.uniform(-0.2, 0.4), 1),
        'accessibility': round(base_rating + random.uniform(-0.4, 0.2), 1)
    }

def business_to_dict(business) -> dict:
    """Convert Business object to dictionary for API response"""
    ratings = generate_mock_rating()
    
    return {
        'id': business.id if hasattr(business, 'id') else f"business_{random.randint(1000, 9999)}",
        'name': business.name if hasattr(business, 'name') else 'Unknown Business',
        'category': business.category if hasattr(business, 'category') else 'Unknown',
        'address': business.address if hasattr(business, 'address') else 'Address not available',
        'city': business.city if hasattr(business, 'city') else 'Unknown City',
        'state': business.state if hasattr(business, 'state') else 'Unknown State',
        'latitude': business.latitude if hasattr(business, 'latitude') else 0.0,
        'longitude': business.longitude if hasattr(business, 'longitude') else 0.0,
        'phone': business.phone if hasattr(business, 'phone') else None,
        'website': business.website if hasattr(business, 'website') else None,
        'opening_hours': business.opening_hours if hasattr(business, 'opening_hours') else 'Hours not available',
        'ratings': ratings,
        'amenities': business.amenities if hasattr(business, 'amenities') else {},
        'verified': random.choice([True, False]),  # Mock verification status
        'photo_count': random.randint(0, 15),
        'review_count': random.randint(5, 150)
    }

@osm_bp.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'service': 'GTGOTG OpenStreetMap API',
        'status': 'healthy',
        'version': '2.0.0',
        'features': [
            'Real Nationwide Business Data',
            'OpenStreetMap Integration',
            'Zero Cost Operation',
            'Comprehensive Coverage'
        ]
    })

@osm_bp.route('/api/search', methods=['GET'])
def search_businesses():
    """Search for businesses with restrooms"""
    try:
        # Get query parameters
        location = request.args.get('location', '').strip()
        category = request.args.get('category', '').strip()
        radius = float(request.args.get('radius', 10))  # Default 10km radius
        
        if not location:
            return jsonify({
                'error': 'Location parameter is required',
                'results': [],
                'total': 0
            }), 400
        
        # Use OSM service if available, otherwise return mock data
        if osm_service:
            try:
                # Search using OpenStreetMap
                businesses = osm_service.search_businesses(
                    location=location,
                    category=category.lower().replace(' ', '_') if category else None,
                    radius_km=radius
                )
                
                # Convert to API format
                results = [business_to_dict(business) for business in businesses]
                
                # Limit results to prevent overwhelming the frontend
                results = results[:50]  # Max 50 results
                
                return jsonify({
                    'results': results,
                    'total': len(results),
                    'location': location,
                    'category': category,
                    'radius_km': radius,
                    'source': 'OpenStreetMap'
                })
                
            except Exception as e:
                print(f"OSM search error: {e}")
                # Fall back to mock data on error
                return generate_mock_results(location, category)
        else:
            # Return mock data if OSM service not available
            return generate_mock_results(location, category)
            
    except Exception as e:
        return jsonify({
            'error': f'Search failed: {str(e)}',
            'results': [],
            'total': 0
        }), 500

def generate_mock_results(location: str, category: str = None):
    """Generate mock results for testing when OSM is not available"""
    mock_businesses = [
        {
            'id': 'mock_1',
            'name': 'Shell Gas Station',
            'category': 'Gas Station',
            'address': '123 Main St',
            'city': location.split(',')[0].strip(),
            'state': 'CO',
            'latitude': 39.7392,
            'longitude': -104.9903,
            'phone': '(303) 555-0123',
            'website': 'https://shell.com',
            'opening_hours': '24/7',
            'ratings': generate_mock_rating(),
            'amenities': {
                'wheelchair_accessible': True,
                'baby_changing_table': False,
                'toilet_paper': True,
                'soap_dispenser': True,
                'paper_towels': True,
                'hand_dryer': True
            },
            'verified': True,
            'photo_count': 8,
            'review_count': 42
        },
        {
            'id': 'mock_2',
            'name': 'Starbucks Coffee',
            'category': 'Coffee Shop',
            'address': '456 Oak Ave',
            'city': location.split(',')[0].strip(),
            'state': 'CO',
            'latitude': 39.7412,
            'longitude': -104.9923,
            'phone': '(303) 555-0456',
            'website': 'https://starbucks.com',
            'opening_hours': '5:00 AM - 10:00 PM',
            'ratings': generate_mock_rating(),
            'amenities': {
                'wheelchair_accessible': True,
                'baby_changing_table': True,
                'toilet_paper': True,
                'soap_dispenser': True,
                'paper_towels': False,
                'hand_dryer': True
            },
            'verified': True,
            'photo_count': 12,
            'review_count': 89
        },
        {
            'id': 'mock_3',
            'name': 'McDonald\'s',
            'category': 'Restaurant',
            'address': '789 Elm St',
            'city': location.split(',')[0].strip(),
            'state': 'CO',
            'latitude': 39.7432,
            'longitude': -104.9943,
            'phone': '(303) 555-0789',
            'website': 'https://mcdonalds.com',
            'opening_hours': '6:00 AM - 11:00 PM',
            'ratings': generate_mock_rating(),
            'amenities': {
                'wheelchair_accessible': True,
                'baby_changing_table': True,
                'toilet_paper': True,
                'soap_dispenser': True,
                'paper_towels': True,
                'hand_dryer': False
            },
            'verified': False,
            'photo_count': 5,
            'review_count': 67
        }
    ]
    
    # Filter by category if specified
    if category:
        mock_businesses = [b for b in mock_businesses if category.lower() in b['category'].lower()]
    
    return jsonify({
        'results': mock_businesses,
        'total': len(mock_businesses),
        'location': location,
        'category': category,
        'radius_km': 10,
        'source': 'Mock Data (OSM integration in progress)'
    })

@osm_bp.route('/api/categories', methods=['GET'])
def get_categories():
    """Get available business categories"""
    if osm_service:
        categories = osm_service.get_categories()
    else:
        # Mock categories
        categories = [
            {'name': 'Gas Station', 'subcategories': ['Service Station']},
            {'name': 'Restaurant', 'subcategories': ['Casual Dining', 'Fast Food']},
            {'name': 'Coffee Shop', 'subcategories': ['Independent Cafe', 'Chain Coffee']},
            {'name': 'Retail Store', 'subcategories': ['Grocery Store', 'Department Store']},
            {'name': 'Hotel', 'subcategories': ['Hotel', 'Motel']},
            {'name': 'Hospital', 'subcategories': ['Medical Center', 'Clinic']},
            {'name': 'Rest Park', 'subcategories': ['City Park', 'Rest Area']}
        ]
    
    return jsonify(categories)

@osm_bp.route('/api/business/<business_id>', methods=['GET'])
def get_business_details(business_id):
    """Get detailed information about a specific business"""
    # This would typically query the database or OSM for specific business details
    # For now, return mock detailed data
    return jsonify({
        'id': business_id,
        'name': 'Sample Business',
        'category': 'Gas Station',
        'address': '123 Main St',
        'city': 'Denver',
        'state': 'CO',
        'latitude': 39.7392,
        'longitude': -104.9903,
        'phone': '(303) 555-0123',
        'website': 'https://example.com',
        'opening_hours': '24/7',
        'ratings': generate_mock_rating(),
        'amenities': {
            'wheelchair_accessible': True,
            'baby_changing_table': False,
            'toilet_paper': True,
            'soap_dispenser': True,
            'paper_towels': True,
            'hand_dryer': True
        },
        'verified': True,
        'photo_count': 8,
        'review_count': 42,
        'reviews': [
            {
                'id': 'review_1',
                'user': 'John D.',
                'rating': 4.5,
                'comment': 'Clean restroom, well maintained.',
                'date': '2025-01-15',
                'helpful_count': 12
            }
        ]
    })

@osm_bp.route('/api/test-osm', methods=['GET'])
def test_osm_connection():
    """Test OpenStreetMap service connection"""
    if not osm_service:
        return jsonify({
            'status': 'error',
            'message': 'OSM service not available',
            'suggestion': 'Using mock data instead'
        })
    
    try:
        # Test geocoding
        location = request.args.get('location', 'Denver, CO')
        geocode_result = osm_service.geocode_location(location)
        
        if geocode_result:
            lat, lon, city, state = geocode_result
            return jsonify({
                'status': 'success',
                'message': 'OSM service is working',
                'test_location': location,
                'geocoded': {
                    'latitude': lat,
                    'longitude': lon,
                    'city': city,
                    'state': state
                }
            })
        else:
            return jsonify({
                'status': 'warning',
                'message': 'OSM service connected but geocoding failed',
                'test_location': location
            })
            
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'OSM service error: {str(e)}'
        })

