#!/usr/bin/env python3
"""
Business Owner model for GTGOTG
Handles business owner registration, verification, and badge system
"""

from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class BusinessOwner(db.Model):
    """Business owner model for managing business listings"""
    id = db.Column(db.Integer, primary_key=True)
    
    # Basic Information
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    phone = db.Column(db.String(20), nullable=True)
    company_name = db.Column(db.String(100), nullable=True)
    
    # Account Status
    is_verified = db.Column(db.Boolean, default=False)
    verification_token = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    
    # Badge System for Business Owners
    response_count = db.Column(db.Integer, default=0)  # Number of review responses
    badge_level = db.Column(db.String(20), default='New Owner')  # Badge progression
    avg_response_time = db.Column(db.Float, default=0.0)  # Average response time in hours
    customer_satisfaction = db.Column(db.Float, default=0.0)  # Based on review improvements
    
    # Business Management
    claimed_businesses = db.Column(db.Text, default='[]')  # JSON array of claimed business IDs
    total_reviews_received = db.Column(db.Integer, default=0)
    total_photos_uploaded = db.Column(db.Integer, default=0)
    
    def __repr__(self):
        return f'<BusinessOwner {self.email}>'
    
    def get_claimed_businesses(self):
        """Get list of business IDs this owner has claimed"""
        try:
            return json.loads(self.claimed_businesses or '[]')
        except:
            return []
    
    def add_claimed_business(self, business_id):
        """Add a business ID to the claimed list"""
        claimed = self.get_claimed_businesses()
        if business_id not in claimed:
            claimed.append(business_id)
            self.claimed_businesses = json.dumps(claimed)
            self.update_badge_level()
    
    def remove_claimed_business(self, business_id):
        """Remove a business ID from the claimed list"""
        claimed = self.get_claimed_businesses()
        if business_id in claimed:
            claimed.remove(business_id)
            self.claimed_businesses = json.dumps(claimed)
    
    def update_badge_level(self):
        """Update business owner badge level based on performance metrics"""
        # Calculate score based on multiple factors
        score = 0
        
        # Response activity (40% weight)
        if self.response_count >= 50:
            score += 40
        elif self.response_count >= 20:
            score += 30
        elif self.response_count >= 10:
            score += 20
        elif self.response_count >= 5:
            score += 10
        
        # Response time (30% weight) - Lower is better
        if self.avg_response_time <= 2:  # 2 hours or less
            score += 30
        elif self.avg_response_time <= 6:  # 6 hours or less
            score += 25
        elif self.avg_response_time <= 24:  # 1 day or less
            score += 15
        elif self.avg_response_time <= 72:  # 3 days or less
            score += 5
        
        # Customer satisfaction (30% weight)
        if self.customer_satisfaction >= 4.5:
            score += 30
        elif self.customer_satisfaction >= 4.0:
            score += 25
        elif self.customer_satisfaction >= 3.5:
            score += 15
        elif self.customer_satisfaction >= 3.0:
            score += 10
        
        # Determine badge level
        if score >= 85:
            self.badge_level = 'Elite Owner'
        elif score >= 70:
            self.badge_level = 'Gold Owner'
        elif score >= 55:
            self.badge_level = 'Silver Owner'
        elif score >= 40:
            self.badge_level = 'Bronze Owner'
        elif score >= 25:
            self.badge_level = 'Active Owner'
        else:
            self.badge_level = 'New Owner'
    
    def get_badge_info(self):
        """Get badge information including icon and description"""
        badge_info = {
            'New Owner': {
                'icon': '🆕',
                'color': '#6B7280',
                'description': 'Welcome! Start responding to reviews to earn higher badges.'
            },
            'Active Owner': {
                'icon': '📝',
                'color': '#10B981',
                'description': 'Actively engaging with customers. Keep it up!'
            },
            'Bronze Owner': {
                'icon': '🥉',
                'color': '#CD7F32',
                'description': 'Consistent customer engagement. Great work!'
            },
            'Silver Owner': {
                'icon': '🥈',
                'color': '#C0C0C0',
                'description': 'Excellent customer service and quick responses.'
            },
            'Gold Owner': {
                'icon': '🥇',
                'color': '#FFD700',
                'description': 'Outstanding customer care and business management.'
            },
            'Elite Owner': {
                'icon': '👑',
                'color': '#9333EA',
                'description': 'Exceptional business owner with top-tier customer service.'
            }
        }
        
        return badge_info.get(self.badge_level, badge_info['New Owner'])
    
    def to_dict(self):
        badge_info = self.get_badge_info()
        return {
            'id': self.id,
            'email': self.email,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'phone': self.phone,
            'company_name': self.company_name,
            'is_verified': self.is_verified,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'response_count': self.response_count,
            'badge_level': self.badge_level,
            'badge_icon': badge_info['icon'],
            'badge_color': badge_info['color'],
            'badge_description': badge_info['description'],
            'avg_response_time': self.avg_response_time,
            'customer_satisfaction': self.customer_satisfaction,
            'claimed_businesses': self.get_claimed_businesses(),
            'total_reviews_received': self.total_reviews_received,
            'total_photos_uploaded': self.total_photos_uploaded
        }


class BusinessClaim(db.Model):
    """Model for tracking business ownership claims"""
    id = db.Column(db.Integer, primary_key=True)
    business_owner_id = db.Column(db.Integer, db.ForeignKey('business_owner.id'), nullable=False)
    business_id = db.Column(db.String(100), nullable=False)
    business_name = db.Column(db.String(200), nullable=False)
    business_address = db.Column(db.String(300), nullable=False)
    
    # Claim Status
    status = db.Column(db.String(20), default='pending')  # pending, approved, rejected
    claim_date = db.Column(db.DateTime, default=datetime.utcnow)
    verification_date = db.Column(db.DateTime, nullable=True)
    
    # Verification Information
    verification_method = db.Column(db.String(50), nullable=True)  # email, phone, document
    verification_data = db.Column(db.Text, nullable=True)  # JSON with verification details
    admin_notes = db.Column(db.Text, nullable=True)
    
    # Relationships
    business_owner = db.relationship('BusinessOwner', backref=db.backref('claims', lazy=True))
    
    def __repr__(self):
        return f'<BusinessClaim {self.business_name} by {self.business_owner_id}>'
    
    def get_verification_data(self):
        """Get verification data as dict"""
        try:
            return json.loads(self.verification_data or '{}')
        except:
            return {}
    
    def set_verification_data(self, data_dict):
        """Set verification data from dict"""
        self.verification_data = json.dumps(data_dict)
    
    def to_dict(self):
        return {
            'id': self.id,
            'business_owner_id': self.business_owner_id,
            'business_id': self.business_id,
            'business_name': self.business_name,
            'business_address': self.business_address,
            'status': self.status,
            'claim_date': self.claim_date.isoformat() if self.claim_date else None,
            'verification_date': self.verification_date.isoformat() if self.verification_date else None,
            'verification_method': self.verification_method,
            'verification_data': self.get_verification_data(),
            'admin_notes': self.admin_notes,
            'business_owner': self.business_owner.to_dict() if self.business_owner else None
        }


class ReviewResponse(db.Model):
    """Model for business owner responses to reviews"""
    id = db.Column(db.Integer, primary_key=True)
    review_id = db.Column(db.Integer, nullable=False)  # References Review.id
    business_owner_id = db.Column(db.Integer, db.ForeignKey('business_owner.id'), nullable=False)
    
    # Response Content
    response_text = db.Column(db.Text, nullable=False)
    response_date = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Response Metrics
    is_helpful = db.Column(db.Boolean, default=False)
    helpful_votes = db.Column(db.Integer, default=0)
    
    # Relationships
    business_owner = db.relationship('BusinessOwner', backref=db.backref('responses', lazy=True))
    
    def __repr__(self):
        return f'<ReviewResponse {self.id} by {self.business_owner_id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'review_id': self.review_id,
            'business_owner_id': self.business_owner_id,
            'response_text': self.response_text,
            'response_date': self.response_date.isoformat() if self.response_date else None,
            'is_helpful': self.is_helpful,
            'helpful_votes': self.helpful_votes,
            'business_owner': self.business_owner.to_dict() if self.business_owner else None
        }

