#!/usr/bin/env python3
"""
Review API routes for GTGOTG
Handles user reviews, ratings, and badge system
"""

from flask import Blueprint, request, jsonify, session
from src.models.user import db, User, Review
import json

reviews_bp = Blueprint('reviews', __name__)

@reviews_bp.route('/api/reviews', methods=['POST'])
def create_review():
    """Create a new review for a business"""
    try:
        # Check if user is logged in
        if 'user_id' not in session:
            return jsonify({'error': 'Login required to submit reviews'}), 401
        
        data = request.get_json()
        user_id = session['user_id']
        
        # Validate required fields
        required_fields = ['business_id', 'overall_rating', 'cleanliness_rating', 'safety_rating']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Check if user already reviewed this business
        existing_review = Review.query.filter_by(
            user_id=user_id, 
            business_id=data['business_id']
        ).first()
        
        if existing_review:
            return jsonify({'error': 'You have already reviewed this business'}), 400
        
        # Create new review
        review = Review(
            user_id=user_id,
            business_id=data['business_id'],
            overall_rating=float(data['overall_rating']),
            cleanliness_rating=float(data['cleanliness_rating']),
            safety_rating=float(data['safety_rating']),
            accessibility_rating=float(data.get('accessibility_rating', 0)),
            comment=data.get('comment', ''),
        )
        
        # Set amenities if provided
        if 'amenities' in data:
            review.set_amenities(data['amenities'])
        
        # Add photos if provided
        if 'photos' in data and isinstance(data['photos'], list):
            review.photos = json.dumps(data['photos'])
        
        db.session.add(review)
        
        # Update user badge system
        user = User.query.get(user_id)
        if user:
            user.add_reviewed_business(data['business_id'])
            if 'photos' in data and data['photos']:
                user.photos_uploaded += len(data['photos'])
        
        db.session.commit()
        
        return jsonify({
            'message': 'Review submitted successfully!',
            'review': review.to_dict(),
            'user_badge_update': user.to_dict() if user else None
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Failed to create review: {str(e)}'}), 500

@reviews_bp.route('/api/reviews/<business_id>', methods=['GET'])
def get_business_reviews(business_id):
    """Get all reviews for a specific business"""
    try:
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 10))
        
        reviews = Review.query.filter_by(business_id=business_id)\
                             .order_by(Review.created_at.desc())\
                             .paginate(page=page, per_page=per_page, error_out=False)
        
        # Calculate average ratings
        all_reviews = Review.query.filter_by(business_id=business_id).all()
        
        if all_reviews:
            avg_overall = sum(r.overall_rating for r in all_reviews) / len(all_reviews)
            avg_cleanliness = sum(r.cleanliness_rating for r in all_reviews) / len(all_reviews)
            avg_safety = sum(r.safety_rating for r in all_reviews) / len(all_reviews)
            avg_accessibility = sum(r.accessibility_rating for r in all_reviews if r.accessibility_rating) / max(1, len([r for r in all_reviews if r.accessibility_rating]))
            
            # Aggregate amenities data
            amenities_summary = {}
            for review in all_reviews:
                review_amenities = review.get_amenities()
                for amenity, value in review_amenities.items():
                    if amenity not in amenities_summary:
                        amenities_summary[amenity] = {'yes': 0, 'no': 0, 'total': 0}
                    amenities_summary[amenity]['total'] += 1
                    if value:
                        amenities_summary[amenity]['yes'] += 1
                    else:
                        amenities_summary[amenity]['no'] += 1
            
            # Calculate percentages
            for amenity in amenities_summary:
                total = amenities_summary[amenity]['total']
                if total > 0:
                    amenities_summary[amenity]['percentage'] = round((amenities_summary[amenity]['yes'] / total) * 100, 1)
                else:
                    amenities_summary[amenity]['percentage'] = 0
        else:
            avg_overall = avg_cleanliness = avg_safety = avg_accessibility = 0
            amenities_summary = {}
        
        return jsonify({
            'reviews': [review.to_dict() for review in reviews.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': reviews.total,
                'pages': reviews.pages,
                'has_next': reviews.has_next,
                'has_prev': reviews.has_prev
            },
            'summary': {
                'total_reviews': len(all_reviews),
                'average_ratings': {
                    'overall': round(avg_overall, 1),
                    'cleanliness': round(avg_cleanliness, 1),
                    'safety': round(avg_safety, 1),
                    'accessibility': round(avg_accessibility, 1)
                },
                'amenities': amenities_summary
            }
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to get reviews: {str(e)}'}), 500

@reviews_bp.route('/api/reviews/<int:review_id>/helpful', methods=['POST'])
def mark_review_helpful(review_id):
    """Mark a review as helpful"""
    try:
        review = Review.query.get_or_404(review_id)
        review.helpful_votes += 1
        
        # Update user's helpful votes count
        user = User.query.get(review.user_id)
        if user:
            user.total_helpful_votes += 1
        
        db.session.commit()
        
        return jsonify({
            'message': 'Review marked as helpful',
            'helpful_votes': review.helpful_votes
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Failed to mark review as helpful: {str(e)}'}), 500

@reviews_bp.route('/api/user/profile', methods=['GET'])
def get_user_profile():
    """Get current user's profile with badge information"""
    try:
        if 'user_id' not in session:
            return jsonify({'error': 'Login required'}), 401
        
        user = User.query.get(session['user_id'])
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Get user's recent reviews
        recent_reviews = Review.query.filter_by(user_id=user.id)\
                                   .order_by(Review.created_at.desc())\
                                   .limit(5).all()
        
        return jsonify({
            'user': user.to_dict(),
            'recent_reviews': [review.to_dict() for review in recent_reviews],
            'badge_progress': {
                'current_level': user.badge_level,
                'current_reviews': user.review_count,
                'next_milestone': user.get_badge_info()['next_level'],
                'reviews_needed': user.get_badge_info()['reviews_needed']
            }
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to get user profile: {str(e)}'}), 500

@reviews_bp.route('/api/amenities/template', methods=['GET'])
def get_amenities_template():
    """Get the standard amenities checklist template"""
    return jsonify({
        'amenities': [
            {
                'id': 'toilet_paper',
                'name': 'Toilet Paper Available',
                'icon': '🧻',
                'category': 'basic'
            },
            {
                'id': 'soap_dispenser',
                'name': 'Soap Dispenser Working',
                'icon': '🧼',
                'category': 'basic'
            },
            {
                'id': 'paper_towels',
                'name': 'Paper Towels Available',
                'icon': '📄',
                'category': 'basic'
            },
            {
                'id': 'hand_dryer',
                'name': 'Hand Air Dryer Working',
                'icon': '💨',
                'category': 'basic'
            },
            {
                'id': 'baby_changing_table',
                'name': 'Baby Changing Table Present',
                'icon': '👶',
                'category': 'family'
            },
            {
                'id': 'wheelchair_accessible',
                'name': 'Wheelchair Accessible',
                'icon': '♿',
                'category': 'accessibility'
            },
            {
                'id': 'wheelchair_stall',
                'name': 'Wheelchair Accessible Stall',
                'icon': '🚪',
                'category': 'accessibility'
            },
            {
                'id': 'grab_bars',
                'name': 'Grab Bars Present',
                'icon': '🤝',
                'category': 'accessibility'
            },
            {
                'id': 'lowered_sink',
                'name': 'Lowered Sink Available',
                'icon': '🚰',
                'category': 'accessibility'
            },
            {
                'id': 'good_lighting',
                'name': 'Good Lighting',
                'icon': '💡',
                'category': 'safety'
            },
            {
                'id': 'clean_floors',
                'name': 'Clean Floors',
                'icon': '✨',
                'category': 'cleanliness'
            },
            {
                'id': 'working_lock',
                'name': 'Working Door Lock',
                'icon': '🔒',
                'category': 'safety'
            }
        ]
    })

@reviews_bp.route('/api/leaderboard', methods=['GET'])
def get_user_leaderboard():
    """Get top users by review count and badge level"""
    try:
        # Get top reviewers
        top_reviewers = User.query.filter(User.review_count > 0)\
                                 .order_by(User.review_count.desc())\
                                 .limit(20).all()
        
        # Get badge distribution
        badge_counts = db.session.query(User.badge_level, db.func.count(User.id))\
                                .group_by(User.badge_level)\
                                .all()
        
        return jsonify({
            'top_reviewers': [user.to_dict() for user in top_reviewers],
            'badge_distribution': {badge: count for badge, count in badge_counts},
            'total_users': User.query.count(),
            'total_reviews': Review.query.count()
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to get leaderboard: {str(e)}'}), 500

